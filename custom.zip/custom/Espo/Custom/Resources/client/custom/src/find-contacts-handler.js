define("custom:find-contacts-handler", ["custom:utils"], function (utils) {
  return function (args) {
    // 1. Get the ID of the current Lead record.
    var currentRecordId = app.getRecordId();

    // 2. Fetch the current record details (Lead entity).
    app.dataApi.get("Lead", currentRecordId, {}, function (lead) {
      // 3. Get the email from the Lead record.
      var leadEmail = lead.email; // Assuming the email field is named 'email' in Lead entity

      // 4. Search for contacts with the same email.
      app.dataApi.get(
        "Contact",
        {
          filter: {
            conditions: [
              { attribute: "email", operator: "=", value: leadEmail },
            ],
          },
        },
        function (contacts) {
          // 5. Display an alert with the names of contacts with the same email, or indicate if no contacts were found.
          if (contacts.length > 0) {
            // Found contacts, display their names.
            var contactNames = contacts
              .map(function (contact) {
                return contact.name;
              })
              .join(", ");

            alert("Contacts with the same email: " + contactNames);
          } else {
            // No contacts found with the same email.
            alert("No contacts found with the same email.");
          }
        }
      );
    });
  };
});
